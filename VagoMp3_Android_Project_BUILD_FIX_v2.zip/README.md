# VagoMp3

Premium Azərbaycan dilində Android MP3 Player layihəsi.

- App: VagoMp3
- Package: `com.vagomp3.app`
- Min SDK: 24
- Target/Compile SDK: 36
- Java: 17
- Debug və Release APK GitHub Actions ilə build olunur.

## GitHub

Bu ZIP-i repository-yə bir ZIP faylı kimi də yükləyə bilərsiniz. Workflow ZIP-i avtomatik tapıb çıxarır və layihəni build edir. İstəsəniz ZIP-in içindəki layihə fayllarını birbaşa repository root-a da yerləşdirə bilərsiniz.

Actions → **Build VagoMp3 APK** → **Run workflow**.

Build bitdikdən sonra `VagoMp3-APKs` artifact-i içindən APK-ları götürün.
