# VagoMp3 — Neon Wolf FIX7

This build fixes the startup/splash and launcher icon architecture.

- AndroidX SplashScreen API installed before `super.onCreate()`.
- Android 12+ startup window uses the Neon Wolf artwork and purple/black background.
- Pre-Android 12 launch window also shows the same Neon Wolf artwork.
- The custom Compose splash remains exactly 3 seconds and includes 0–100% progress.
- Splash language follows the phone language: Azerbaijani, English, Russian, Turkish.
- Launcher icon and round launcher icon now point to the Neon Wolf adaptive icon.
- Old launcher WebP resources were removed so the old icon cannot win during resource selection.
- Legacy density launcher PNGs were regenerated from the selected Neon Wolf image.
- `versionCode` remains 2 and `versionName` remains 1.0.1.

Important: Android launch behavior is system-controlled. The AndroidX splash makes the startup window visually match the requested splash instead of showing a blank black screen. The 3-second animated progress is the app's own Compose splash after the first frame.
