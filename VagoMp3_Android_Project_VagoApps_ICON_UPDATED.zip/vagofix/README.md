# VagoMp3 — startup/splash FIX7

This archive contains the startup fixes applied to the supplied project.

## Fixed
- AndroidX SplashScreen remains installed before `super.onCreate()`.
- MainViewModel/player/preferences initialization is moved out of the
  pre-Compose startup path.
- The first Compose frame can render the custom splash immediately.
- The custom splash cannot transition to the main screen until both:
  1. the splash animation has completed, and
  2. ViewModel initialization is ready.
- This removes the avoidable black/blank transition caused by startup work.
- Removed the unused `rememberSaveable` import.
- The existing `Artwork()` implementation uses `LocalContext.current` and
  `contentResolver` correctly.
- Existing launcher icon resources and neon wolf artwork are preserved.
- Existing app features and data structures are not intentionally removed.

## Splash behavior
App launch -> Android startup splash -> custom VagoMp3 neon splash ->
0–100% progress -> main screen.

The custom splash remains 3 seconds as already designed in the project.
The Android system startup splash is necessarily controlled by Android and
is kept visually consistent with the app's dark neon background.

## Build
Run from the `vagofix` directory:

    ./gradlew :app:assembleDebug

The supplied archive did not contain a Gradle wrapper, so this environment
cannot truthfully claim a Gradle build was executed here.
