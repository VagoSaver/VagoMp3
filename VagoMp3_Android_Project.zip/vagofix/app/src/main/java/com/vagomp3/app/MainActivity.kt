package com.vagomp3.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.util.Locale

private var Bg = Color(0xFF04020B)
private var Surface = Color(0xFF12102A)
private var Surface2 = Color(0xFF21153D)
private var Border = Color(0xFF55358A)
private var Purple = Color(0xFFB026FF)
private var Pink = Color(0xFFFF197A)
private var Cyan = Color(0xFF00E5FF)
private var Gold = Color(0xFFFFD166)
private var Muted = Color(0xFFB6A9D6)
private var White = Color(0xFFFFFFFF)

private fun applyVagoTheme(index: Int) {
    when (index) {
        1 -> { // Cyberpunk
            Bg=Color(0xFF05010D); Surface=Color(0xFF12051F); Surface2=Color(0xFF24103A)
            Border=Color(0xFF7B2CFF); Purple=Color(0xFFFF00E5); Pink=Color(0xFFFF2D95)
            Cyan=Color(0xFF00F0FF); Gold=Color(0xFFFFD166); Muted=Color(0xFFC5A9E8); White=Color.White
        }
        2 -> { // Electric Blue
            Bg=Color(0xFF020611); Surface=Color(0xFF07142B); Surface2=Color(0xFF0D2345)
            Border=Color(0xFF1769FF); Purple=Color(0xFF3D5AFE); Pink=Color(0xFF00B8FF)
            Cyan=Color(0xFF00F5FF); Gold=Color(0xFFFFD166); Muted=Color(0xFFA7C4F5); White=Color.White
        }
        3 -> { // Toxic Green
            Bg=Color(0xFF020A06); Surface=Color(0xFF07170D); Surface2=Color(0xFF0D2A18)
            Border=Color(0xFF19A85B); Purple=Color(0xFF39FF88); Pink=Color(0xFFB7FF00)
            Cyan=Color(0xFF00FFD5); Gold=Color(0xFFFFE082); Muted=Color(0xFFA7D9B8); White=Color.White
        }
        4 -> { // Luxury Gold
            Bg=Color(0xFF090704); Surface=Color(0xFF17100A); Surface2=Color(0xFF2A1C0D)
            Border=Color(0xFF8D6B24); Purple=Color(0xFFFFC857); Pink=Color(0xFFFF8A00)
            Cyan=Color(0xFFFFE082); Gold=Color(0xFFFFD166); Muted=Color(0xFFD8C39A); White=Color.White
        }
        else -> { // Vago Premium Neon
            Bg=Color(0xFF03020A); Surface=Color(0xFF0C0A1C); Surface2=Color(0xFF17112D)
            Border=Color(0xFF6E36B8); Purple=Color(0xFFB026FF); Pink=Color(0xFFFF167F)
            Cyan=Color(0xFF00E5FF); Gold=Color(0xFFFFD166); Muted=Color(0xFFB9A9D8); White=Color.White
        }
    }
}

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val albumId: Long
)

enum class Page { HOME, SONGS, ALBUMS, ARTISTS, FAVORITES, SETTINGS, PLAYER, EQUALIZER }

class AudioLibrary(private val context: Context) {
    suspend fun scan(): List<Song> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA
        )
        // Only show real music files; exclude WhatsApp voice/audio files.
        val dataColumn = MediaStore.Audio.Media.DATA
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND " +
            "${MediaStore.Audio.Media.DURATION} > 5000 AND " +
            "($dataColumn IS NULL OR (" +
            "$dataColumn NOT LIKE '%/WhatsApp/%' AND " +
            "$dataColumn NOT LIKE '%/WhatsApp Audio/%' AND " +
            "$dataColumn NOT LIKE '%/WhatsApp Voice Notes/%' AND " +
            "$dataColumn NOT LIKE '%/WhatsApp/Media/WhatsApp Audio/%'" +
            "))"
        context.contentResolver.query(collection, projection, selection, null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (c.moveToNext()) {
                val songId = c.getLong(id)
                result += Song(
                    songId,
                    c.getString(title)?.ifBlank { "Adsız mahnı" } ?: "Adsız mahnı",
                    resolveArtist(context, ContentUris.withAppendedId(collection, songId), c.getString(artist)),
                    c.getString(album)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Naməlum albom",
                    c.getLong(duration),
                    ContentUris.withAppendedId(collection, songId),
                    c.getLong(albumId)
                )
            }
        }
        result
    }
}

private fun resolveArtist(context: Context, uri: Uri, mediaStoreArtist: String?): String {
    val store = mediaStoreArtist?.trim()
    if (!store.isNullOrEmpty() && !store.equals("<unknown>", true) && !store.equals("unknown", true)) return store
    return try {
        val retriever = android.media.MediaMetadataRetriever()
        retriever.setDataSource(context, uri)
        val meta = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim()
        retriever.release()
        if (!meta.isNullOrEmpty() && !meta.equals("<unknown>", true)) meta else "Naməlum ifaçı"
    } catch (_: Exception) { "Naməlum ifaçı" }
}

class PlayerController(private val context: Context) {
    private var player: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: android.media.audiofx.BassBoost? = null
    private var virtualizer: android.media.audiofx.Virtualizer? = null
    private val _current = MutableStateFlow<Song?>(null)
    val current: StateFlow<Song?> = _current.asStateFlow()
    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing.asStateFlow()
    private val _position = MutableStateFlow(0)
    val position: StateFlow<Int> = _position.asStateFlow()
    private var queue: List<Song> = emptyList()
    private var queueIndex: Int = -1
    private var shuffle = false
    private var repeat = false

    fun setQueue(songs: List<Song>, start: Song? = null) {
        queue = songs
        queueIndex = start?.let { songs.indexOfFirst { s -> s.id == it.id } }?.takeIf { it >= 0 } ?: queueIndex
    }

    fun setShuffle(enabled: Boolean) { shuffle = enabled }
    fun setRepeat(enabled: Boolean) { repeat = enabled }
    fun isShuffle() = shuffle
    fun isRepeat() = repeat

    fun play(song: Song) {
        if (queue.isNotEmpty()) {
            queueIndex = queue.indexOfFirst { it.id == song.id }.takeIf { it >= 0 } ?: queueIndex
        }
        if (_current.value?.id == song.id && player != null) {
            player?.start(); _playing.value = true; return
        }
        release()
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_MEDIA).build())
            setDataSource(context, song.uri)
            setOnPreparedListener { it.start(); _playing.value = true }
            setOnErrorListener { _, _, _ ->
                _playing.value = false
                _position.value = 0
                true
            }
            setOnCompletionListener {
                _position.value = 0
                if (repeat) {
                    release()
                    play(song)
                } else {
                    next()
                }
            }
            prepareAsync()
        }
        _current.value = song
        _position.value = 0
    }

    fun pause() {
        player?.pause()
        _playing.value = false
    }

    fun toggle() {
        try {
            player?.let { if (it.isPlaying) { it.pause(); _playing.value = false } else { it.start(); _playing.value = true } }
        } catch (_: IllegalStateException) {
            _playing.value = false
        }
    }

    fun seekTo(ms: Int) {
        val safe = ms.coerceAtLeast(0)
        try { player?.seekTo(safe) } catch (_: IllegalStateException) { return }
        _position.value = safe
    }
    fun updatePosition() { player?.let { if (it.isPlaying) _position.value = it.currentPosition } }

    fun next() {
        if (queue.isEmpty()) { _playing.value = false; return }
        val nextIndex = if (shuffle && queue.size > 1) {
            var i = 0
            do { i = (0 until queue.size).random() } while (i == queueIndex)
            i
        } else (queueIndex + 1) % queue.size
        queueIndex = nextIndex
        play(queue[queueIndex])
    }

    fun previous() {
        if (queue.isEmpty()) { seekTo(0); return }
        if ((_position.value > 3000)) { seekTo(0); return }
        queueIndex = if (queueIndex - 1 < 0) queue.lastIndex else queueIndex - 1
        play(queue[queueIndex])
    }

    fun setBassBoost(value: Float) {
        try {
            val session = player?.audioSessionId ?: return
            if (bassBoost == null) bassBoost = android.media.audiofx.BassBoost(0, session)
            bassBoost?.enabled = true
            bassBoost?.setStrength((value.coerceIn(0f, 1f) * 1000).toInt().toShort())
        } catch (_: Throwable) {
            bassBoost?.release()
            bassBoost = null
        }
    }

    fun setVirtualizer(value: Float) {
        try {
            val session = player?.audioSessionId ?: return
            if (virtualizer == null) virtualizer = android.media.audiofx.Virtualizer(0, session)
            virtualizer?.enabled = true
            virtualizer?.setStrength((value.coerceIn(0f, 1f) * 1000).toInt().toShort())
        } catch (_: Throwable) {
            virtualizer?.release()
            virtualizer = null
        }
    }

    fun setEqualizer(preset: Int) {
        try {
            val audioSession = player?.audioSessionId ?: return
            equalizer?.release()
            equalizer = Equalizer(0, audioSession).apply {
                enabled = true
                val count = numberOfPresets
                if (count > 0) usePreset(preset.coerceIn(0, count - 1).toShort())
            }
        } catch (_: Throwable) {
            equalizer?.release()
            equalizer = null
        }
    }

    fun release() {
        equalizer?.release(); equalizer = null
        bassBoost?.release(); bassBoost = null
        virtualizer?.release(); virtualizer = null
        player?.release(); player = null
        _playing.value = false
    }
}

class MainViewModel : ViewModel() {
    lateinit var context: Context
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs = _songs.asStateFlow()
    private val _page = MutableStateFlow(Page.HOME)
    val page = _page.asStateFlow()
    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()
    private val _darkTheme = MutableStateFlow(true)
    val darkTheme = _darkTheme.asStateFlow()
    private val _theme = MutableStateFlow(0)
    val theme = _theme.asStateFlow()
    private val _language = MutableStateFlow("system")
    val language = _language.asStateFlow()
    private val _sleepRemaining = MutableStateFlow(0)
    val sleepRemaining = _sleepRemaining.asStateFlow()
    private var sleepJob: Job? = null
    private val _favorites = MutableStateFlow<Set<Long>>(emptySet())
    val favorites = _favorites.asStateFlow()
    lateinit var player: PlayerController

    fun init(ctx: Context) {
        if (::context.isInitialized) return
        context = ctx.applicationContext
        player = PlayerController(context)
        loadFavorites()
        val prefs = context.getSharedPreferences("vagomp3_settings", 0)
        _darkTheme.value = prefs.getBoolean("dark", true)
        _theme.value = prefs.getInt("theme_index", 0).coerceIn(0, 4)
        _language.value = prefs.getString("language", "system") ?: "system"
        applyVagoTheme(_theme.value)
        // Initial media scan is triggered by MainActivity after permission is confirmed.
    }

    private fun loadFavorites() {
        val prefs = context.getSharedPreferences("vagomp3", Context.MODE_PRIVATE)
        val raw = prefs.getStringSet("favorites", emptySet()).orEmpty().toSet()
        _favorites.value = raw.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun scan() { viewModelScope.launch { _songs.value = AudioLibrary(context).scan() } }
    fun setPage(p: Page) { _page.value = p }
    fun toggleTheme() {
        setTheme(((_theme.value + 1) % 5))
    }
    fun setTheme(index: Int) {
        val i=index.coerceIn(0,4)
        _theme.value=i
        _darkTheme.value=true
        applyVagoTheme(i)
        context.getSharedPreferences("vagomp3_settings", 0).edit()
            .putInt("theme_index", i).putBoolean("dark", true).apply()
    }
    fun setLanguage(code: String) {
        val safeCode = when (code.lowercase(Locale.ROOT)) {
            "system", "az", "en", "ru", "tr" -> code.lowercase(Locale.ROOT)
            else -> "system"
        }
        _language.value = safeCode
        context.getSharedPreferences("vagomp3_settings", 0).edit()
            .putString("language", safeCode).apply()
    }
    fun startSleepTimer(minutes: Int) {
        if (minutes <= 0) return
        sleepJob?.cancel()
        val endAt = android.os.SystemClock.elapsedRealtime() + minutes * 60_000L
        context.getSharedPreferences("vagomp3_settings", Context.MODE_PRIVATE)
            .edit().putLong("sleep_timer_end", endAt).apply()
        _sleepRemaining.value = minutes
        sleepJob = viewModelScope.launch {
            while (true) {
                val remainingMs = endAt - android.os.SystemClock.elapsedRealtime()
                if (remainingMs <= 0L) break
                _sleepRemaining.value = kotlin.math.ceil(remainingMs / 60_000.0).toInt()
                delay(1_000L)
            }
            _sleepRemaining.value = 0
            context.getSharedPreferences("vagomp3_settings", Context.MODE_PRIVATE)
                .edit().remove("sleep_timer_end").apply()
            player.pause()
        }
    }
    fun cancelSleepTimer() {
        sleepJob?.cancel()
        sleepJob = null
        _sleepRemaining.value = 0
        context.getSharedPreferences("vagomp3_settings", Context.MODE_PRIVATE)
            .edit().remove("sleep_timer_end").apply()
    }
    fun setBassBoost(v: Float) = player.setBassBoost(v)
    fun setVirtualizer(v: Float) = player.setVirtualizer(v)
    fun setQuery(q: String) { _query.value = q }
    fun toggleFavorite(song: Song) {
        val updated = _favorites.value.toMutableSet()
        if (!updated.add(song.id)) updated.remove(song.id)
        val persisted = updated.map(Long::toString).toSet()
        context.getSharedPreferences("vagomp3", Context.MODE_PRIVATE)
            .edit().putStringSet("favorites", persisted).apply()
        _favorites.value = updated.toSet()
    }
    fun play(song: Song) {
        player.setQueue(_songs.value, song)
        player.play(song)
    }
    fun next() = player.next()
    fun previous() = player.previous()
    fun setShuffle(enabled: Boolean) = player.setShuffle(enabled)
    fun setRepeat(enabled: Boolean) = player.setRepeat(enabled)
    fun isShuffle() = player.isShuffle()
    fun isRepeat() = player.isRepeat()
    override fun onCleared() { player.release(); super.onCleared() }
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.scan()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Must be called before super.onCreate(). Android 12+ now shows the same
        // Neon Wolf artwork during process/activity startup, eliminating the
        // previous blank black launch window.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        window.statusBarColor = Bg.toArgb()
        window.navigationBarColor = Bg.toArgb()
        vm.init(this)
        setContent {
            var showSplash by remember { mutableStateOf(true) }
            if (showSplash) {
                VagoSplashScreen(onFinished = { showSplash = false })
            } else {
                VagoMp3App(vm, ::requestAudioPermission)
            }
        }
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED)
            permissionLauncher.launch(permission)
        else vm.scan()
    }
}


private fun effectiveLanguageCode(language: String): String {
    if (language != "system") {
        return when (language.lowercase(Locale.ROOT)) {
            "az", "en", "ru", "tr" -> language.lowercase(Locale.ROOT)
            else -> "en"
        }
    }
    return when (Locale.getDefault().language.lowercase(Locale.ROOT)) {
        "az", "en", "ru", "tr" -> Locale.getDefault().language.lowercase(Locale.ROOT)
        else -> "en"
    }
}

private fun uiText(language: String, key: String): String {
    val lang = effectiveLanguageCode(language)
    return when (lang) {
        "ru" -> mapOf(
            "home" to "Главная","feel" to "Почувствуй музыку.","world" to "Твой музыкальный мир. Ярче, живее.",
            "search" to "Искать песню, исполнителя или альбом...","songs" to "Песни","albums" to "Альбомы",
            "favorites" to "Избранное","recent" to "Недавно прослушанные","all" to "Смотреть все",
            "equalizer" to "Мощный эквалайзер","equalizer_sub" to "Настрой звук под свой вкус",
            "no_music" to "Музыка не найдена","no_music_sub" to "Добавьте MP3 или другие аудиофайлы на телефон.",
            "no_fav" to "Нет избранных песен","no_fav_sub" to "Нажмите на сердце у песни, чтобы она появилась здесь.",
            "playing" to "Сейчас играет","not_selected" to "Песня не выбрана","choose_song" to "Выберите песню из библиотеки.",
            "custom" to "Пользовательский","pop" to "Поп","rock" to "Рок","classical" to "Классика","bass" to "Бас",
            "bass_boost" to "Усилитель басов","virtualizer" to "Виртуализатор","language" to "Язык","system_language" to "Системный язык",
            "settings" to "Настройки","theme" to "Тема","sleep" to "Таймер сна","eq" to "Эквалайзер",
            "notifications" to "Уведомления","background" to "Фоновое воспроизведение","enabled" to "Включено","disabled" to "Выключено",
            "minute" to "мин","open" to "Открыть","activity" to "Активность","artists" to "Исполнители","logo_tag" to "Почувствуй музыку.","add_favorite" to "Добавить в избранное","remove_favorite" to "Удалить из избранного"
        )
        "en" -> mapOf(
            "home" to "Home","feel" to "Feel the music.","world" to "Your music world. Brighter, more alive.",
            "search" to "Search song, artist or album...","songs" to "Songs","albums" to "Albums",
            "favorites" to "Favorites","recent" to "Recently played","all" to "View all",
            "equalizer" to "Powerful Equalizer","equalizer_sub" to "Tune the sound to your taste",
            "no_music" to "No music found","no_music_sub" to "Add MP3 or other audio files to your phone.",
            "no_fav" to "No favorite songs yet","no_fav_sub" to "Tap the heart on a song to see it here.",
            "playing" to "Now Playing","not_selected" to "No song selected","choose_song" to "Choose a song from your library.",
            "custom" to "Custom","pop" to "Pop","rock" to "Rock","classical" to "Classical","bass" to "Bass",
            "bass_boost" to "Bass Booster","virtualizer" to "Virtualizer","language" to "Language","system_language" to "System language",
            "settings" to "Settings","theme" to "Theme","sleep" to "Sleep Timer","eq" to "Equalizer",
            "notifications" to "Notifications","background" to "Background playback","enabled" to "Enabled","disabled" to "Disabled",
            "minute" to "min","open" to "Open","activity" to "Activity","artists" to "Artists","logo_tag" to "Feel the music.","add_favorite" to "Add to favorites","remove_favorite" to "Remove from favorites"
        )
        "tr" -> mapOf(
            "home" to "Ana Sayfa","feel" to "Müziği hisset.","world" to "Müzik dünyan. Daha parlak, daha canlı.",
            "search" to "Şarkı, sanatçı veya albüm ara...","songs" to "Şarkılar","albums" to "Albümler",
            "favorites" to "Favoriler","recent" to "Son dinlenenler","all" to "Tümünü gör",
            "equalizer" to "Güçlü Ekolayzır","equalizer_sub" to "Sesi zevkine göre ayarla",
            "no_music" to "Müzik bulunamadı","no_music_sub" to "Telefonuna MP3 veya diğer ses dosyalarını ekle.",
            "no_fav" to "Henüz favori şarkı yok","no_fav_sub" to "Burada görmek için şarkıdaki kalbe dokun.",
            "playing" to "Şimdi Çalıyor","not_selected" to "Şarkı seçilmedi","choose_song" to "Kitaplığından bir şarkı seç.",
            "custom" to "Özel","pop" to "Pop","rock" to "Rock","classical" to "Klasik","bass" to "Bas",
            "bass_boost" to "Bas Güçlendirici","virtualizer" to "Sanallaştırıcı","language" to "Dil","system_language" to "Sistem dili",
            "settings" to "Ayarlar","theme" to "Tema","sleep" to "Uyku Zamanlayıcısı","eq" to "Ekolayzır",
            "notifications" to "Bildirimler","background" to "Arka planda oynatma","enabled" to "Açık","disabled" to "Kapalı",
            "minute" to "dk","open" to "Aç","activity" to "Sanatçılar","artists" to "Sanatçılar","logo_tag" to "Müziği hisset.","add_favorite" to "Favorilere ekle","remove_favorite" to "Favorilerden çıkar"
        )
        else -> mapOf(
            "home" to "Ana səhifə","feel" to "Musiqini hiss et.","world" to "Sənin musiqi dünyan. Daha parlaq, daha canlı.",
            "search" to "Mahnı, ifaçı və ya albom axtar...","songs" to "Mahnılar","albums" to "Albomlar",
            "favorites" to "Sevimlilər","recent" to "Son dinlədiklərin","all" to "Hamısına bax",
            "equalizer" to "Güclü Ekvalayzer","equalizer_sub" to "Səsini zövqünə uyğunlaşdır",
            "no_music" to "Musiqi tapılmadı","no_music_sub" to "Telefonuna MP3 və ya digər audio fayllar əlavə et.",
            "no_fav" to "Hələ sevimli mahnın yoxdur","no_fav_sub" to "Mahnıdakı ürəyə toxun və burada görünsün.",
            "playing" to "İndi Dinlənilir","not_selected" to "Mahnı seçilməyib","choose_song" to "Kitabxanadan mahnı seç.",
            "custom" to "Xüsusi","pop" to "Pop","rock" to "Rock","classical" to "Klassik","bass" to "Bass",
            "bass_boost" to "Bass Gücləndirici","virtualizer" to "Virtuallaşdırıcı","language" to "Dil","system_language" to "Sistem dili",
            "settings" to "Parametrlər","theme" to "Tema","sleep" to "Yuxu Taymeri","eq" to "Ekvalayzer",
            "notifications" to "Bildirişlər","background" to "Fon rejimində dinləmə","enabled" to "Aktiv","disabled" to "Deaktiv",
            "minute" to "dəq","open" to "Aç","activity" to "Fəaliyyət","artists" to "İfaçılar","logo_tag" to "Musiqini hiss et.","add_favorite" to "Sevimlilərə əlavə et","remove_favorite" to "Sevimlilərdən çıxar"
        )
    }[key] ?: key
}


@Composable
private fun VagoSplashScreen(onFinished: () -> Unit) {
    val systemLanguage = Locale.getDefault().language.lowercase(Locale.ROOT)
    val loadingText = when (systemLanguage) {
        "az" -> "Yüklənir..."
        "ru" -> "Загрузка..."
        "tr" -> "Yükleniyor..."
        else -> "Loading..."
    }
    var progress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val durationMs = 3000L
        val stepMs = 30L
        val steps = durationMs / stepMs
        repeat(steps.toInt()) { step ->
            progress = (step + 1).toFloat() / steps.toFloat()
            delay(stepMs)
        }
        progress = 1f
        onFinished()
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(Color(0xFF17062E), Color(0xFF05020C), Color.Black),
                radius = 900f
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 42.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.neon_wolf_logo),
                contentDescription = "VagoMp3 Neon Wolf",
                modifier = Modifier.size(250.dp).clip(RoundedCornerShape(34.dp))
            )
            Spacer(Modifier.height(28.dp))
            Text(
                "VagoMp3",
                color = White,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.height(8.dp))
            Text(loadingText, color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(10.dp)),
                color = Purple,
                trackColor = Color.White.copy(alpha = 0.10f)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "${(progress * 100).toInt()}%",
                color = Purple,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun VagoMp3App(vm: MainViewModel, requestPermission: () -> Unit) {
    val songs by vm.songs.collectAsState()
    val page by vm.page.collectAsState()
    val query by vm.query.collectAsState()
    val current by vm.player.current.collectAsState()
    val playing by vm.player.playing.collectAsState()
    val position by vm.player.position.collectAsState()
    val darkTheme by vm.darkTheme.collectAsState()
    val themeIndex by vm.theme.collectAsState()
    val language by vm.language.collectAsState()

    LaunchedEffect(themeIndex) { applyVagoTheme(themeIndex) }
    LaunchedEffect(Unit) { requestPermission() }
    LaunchedEffect(playing) {
        while (playing) { vm.player.updatePosition(); delay(500) }
    }
    BackHandler(enabled = page != Page.HOME) { vm.setPage(Page.HOME) }

    val filtered = songs.filter {
        query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Pink, tertiary = Cyan,
        background = Bg, surface = Surface, onSurface = White, onBackground = White
    )) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            AnimatedContent(page, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "page") { p ->
                when (p) {
                    Page.HOME -> HomePage(vm, songs, filtered, current, playing)
                    Page.SONGS -> SongsPage(vm, filtered, current, playing, query)
                    Page.ALBUMS -> AlbumsPage(vm, songs, current, playing)
                    Page.ARTISTS -> ArtistsPage(vm, songs)
                    Page.FAVORITES -> FavoritesPage(vm, songs, current, playing)
                    Page.SETTINGS -> SettingsPage(vm, language)
                    Page.PLAYER -> FullPlayer(vm, current, playing, position)
                    Page.EQUALIZER -> EqualizerPage(vm, playing)
                }
            }
            if (page != Page.PLAYER && page != Page.EQUALIZER) {
                Column(
                    Modifier.fillMaxWidth().align(Alignment.BottomCenter),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    if (current != null) {
                        MiniPlayer(vm, current!!, playing, position)
                    }
                    BottomNav(page, vm::setPage, language)
                }
            }
        }
    }
}

@Composable
private fun Brand(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(
            Brush.linearGradient(listOf(Purple, Pink))).border(1.dp, Color.White.copy(.18f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center) {
            Text("V", color=White, fontSize=20.sp, fontWeight=FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Text("Vago", color=White, fontSize=23.sp, fontWeight=FontWeight.Bold)
        Text("Mp3", color=Pink, fontSize=23.sp, fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun TopBar(title: String = "Ana səhifə", onBack: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack, null, tint=White) }
        } else Brand()
        Spacer(Modifier.weight(1f))
        Text(title, color=White, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
private fun HomePage(vm: MainViewModel, songs: List<Song>, filtered: List<Song>, current: Song?, playing: Boolean) {
    val language by vm.language.collectAsState()
    val ctx=LocalContext.current
    Column(Modifier.fillMaxSize().padding(bottom=180.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Brand()
            IconButton(onClick={vm.setPage(Page.SETTINGS)}) { Icon(Icons.Default.Settings, null, tint=White) }
        }
        Text(uiText(language, "feel"), color=White, fontSize=31.sp, fontWeight=FontWeight.ExtraBold, modifier=Modifier.padding(horizontal=20.dp))
        Text(uiText(language, "world"), color=Muted, fontSize=14.sp, modifier=Modifier.padding(horizontal=20.dp, vertical=4.dp))
        SearchBox(vm)
        Row(Modifier.padding(horizontal=20.dp, vertical=14.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            QuickCard(uiText(language, "songs"), songs.size.toString(), Icons.Default.MusicNote) { vm.setPage(Page.SONGS) }
            QuickCard(uiText(language, "albums"), songs.map { it.album }.distinct().size.toString(), Icons.Default.Album) { vm.setPage(Page.ALBUMS) }
            QuickCard(uiText(language, "favorites"), vm.favorites.value.size.toString(), Icons.Default.Favorite) { vm.setPage(Page.FAVORITES) }
        }
        SectionTitle(uiText(language, "recent"), uiText(language, "all")) { vm.setPage(Page.SONGS) }
        if (filtered.isEmpty()) EmptyState(uiText(language, "no_music"), uiText(language, "no_music_sub"))
        else filtered.take(7).forEach { SongRow(it, vm, current, playing) }
        Spacer(Modifier.height(24.dp))
        FeatureCard(uiText(language, "equalizer"), uiText(language, "equalizer_sub"), Icons.Default.Equalizer) { vm.setPage(Page.EQUALIZER) }
    }
}

@Composable
private fun SearchBox(vm: MainViewModel) {
    val query by vm.query.collectAsState()
    val language by vm.language.collectAsState()
    OutlinedTextField(query, vm::setQuery, Modifier.fillMaxWidth().padding(horizontal=20.dp),
        placeholder={Text(uiText(language, "search"), color=Muted)},
        leadingIcon={Icon(Icons.Default.Search,null,tint=Muted)}, singleLine=true,
        shape=RoundedCornerShape(18.dp), colors=OutlinedTextFieldDefaults.colors(
            focusedBorderColor=Purple, unfocusedBorderColor=Border, focusedContainerColor=Surface, unfocusedContainerColor=Surface,
            focusedTextColor=White, unfocusedTextColor=White, cursorColor=Pink
        ))
}

@Composable
private fun RowScope.QuickCard(title:String, count:String, icon:ImageVector, click:()->Unit) {
    Column(Modifier.weight(1f).height(100.dp).clip(RoundedCornerShape(18.dp)).background(Surface)
        .border(1.dp, Border, RoundedCornerShape(18.dp)).clickable(onClick=click).padding(14.dp),
        verticalArrangement=Arrangement.SpaceBetween) {
        Icon(icon,null,tint=if(title in setOf("Sevimlilər", "Избранное", "Favorites", "Favoriler")) Pink else Cyan,modifier=Modifier.size(25.dp))
        Text(title,color=White,fontSize=13.sp,fontWeight=FontWeight.SemiBold)
        Text(count,color=Muted,fontSize=12.sp)
    }
}

@Composable
private fun SectionTitle(title:String, action:String?=null, onAction:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
        Text(title,color=White,fontSize=18.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        if(action!=null) Text(action,color=Purple,fontSize=12.sp,modifier=Modifier.clickable{onAction?.invoke()})
    }
}

@Composable
private fun SongRow(song:Song,vm:MainViewModel,current:Song?,playing:Boolean) {
    val isFavorite = song.id in vm.favorites.collectAsState().value
    Row(
        Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=5.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if(current?.id==song.id) Color(0xFF211638) else Color.Transparent)
            .clickable { vm.play(song) }
            .padding(8.dp),
        verticalAlignment=Alignment.CenterVertically
    ) {
        Artwork(song, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title,color=White,fontSize=14.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
            Text(song.artist,color=Muted,fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
        }
        Text(formatMs(song.duration),color=Muted,fontSize=11.sp)
        IconButton(
            onClick = { vm.toggleFavorite(song) },
            modifier = Modifier.size(38.dp)
        ) {
            Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                tint = if (isFavorite) Pink else Muted,
                modifier = Modifier.size(22.dp)
            )
        }
        Icon(
            if(current?.id==song.id&&playing) Icons.Default.PauseCircleOutline else Icons.Default.PlayCircleOutline,
            null,
            tint=if(current?.id==song.id)Pink else White,
            modifier=Modifier.padding(start=2.dp).size(27.dp)
        )
    }
}

@Composable
private fun Artwork(song:Song, modifier:Modifier=Modifier) {
    val context = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, song.uri, song.albumId) {
        value = withContext(Dispatchers.IO) {
            var result: android.graphics.Bitmap? = null
            try {
                val r = android.media.MediaMetadataRetriever()
                try {
                    r.setDataSource(context, song.uri)
                    r.embeddedPicture?.let { bytes ->
                        result = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                } finally { r.release() }
            } catch (_:Throwable) {}
            if (result == null && song.albumId > 0L) {
                try {
                    val albumUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"), song.albumId
                    )
                    context.contentResolver.openInputStream(albumUri)?.use { input ->
                        result = android.graphics.BitmapFactory.decodeStream(input)
                    }
                } catch (_:Throwable) {}
            }
            result
        }
    }
    Box(modifier.clip(RoundedCornerShape(13.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF32115A),Color(0xFF0C5E74))))) {
        if (bmp != null) {
            AndroidView(factory = { android.widget.ImageView(it).apply {
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            }}, update = { it.setImageBitmap(bmp) }, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Default.MusicNote,null,tint=White.copy(.7f),
                modifier=Modifier.align(Alignment.Center).size(24.dp))
        }
    }
}

@Composable
private fun SongsPage(vm:MainViewModel,songs:List<Song>,current:Song?,playing:Boolean,query:String) {
    val language by vm.language.collectAsState()
    Column(Modifier.fillMaxSize().padding(bottom=145.dp)) {
        TopBar(uiText(language, "songs")){ }
        SearchBox(vm)
        if(songs.isEmpty()) EmptyState(uiText(language, "no_music"), uiText(language, "no_music_sub"))
        else LazyColumn(Modifier.fillMaxSize().padding(top=10.dp)) { items(songs,key={it.id}){SongRow(it,vm,current,playing)} }
    }
}

@Composable
private fun AlbumsPage(vm:MainViewModel,songs:List<Song>,current:Song?,playing:Boolean) {
    val language by vm.language.collectAsState()
    val albums=songs.groupBy{it.album}.entries.toList()
    Column(Modifier.fillMaxSize().padding(bottom=145.dp)) {
        TopBar(uiText(language, "albums"))
        LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize().padding(horizontal=16.dp),contentPadding=PaddingValues(bottom=12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            items(albums,key={it.key}){ (album,tracks) ->
                Column(Modifier.clip(RoundedCornerShape(18.dp)).background(Surface).border(1.dp,Border,RoundedCornerShape(18.dp)).clickable { vm.play(tracks.first()) }.padding(10.dp)) {
                    Artwork(tracks.first(),Modifier.fillMaxWidth().aspectRatio(1f))
                    Text(album,color=White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(top=9.dp))
                    Text("${tracks.size} ${uiText(language, "songs").lowercase()}",color=Muted,fontSize=12.sp)
                }
            }
        }
    }
}

@Composable
private fun ArtistsPage(vm: MainViewModel, songs: List<Song>) {
    val language by vm.language.collectAsState()
    val artists = songs.filter { it.artist.isNotBlank() && !it.artist.equals("Naməlum ifaçı", true) }.groupBy { it.artist.trim() }.entries.sortedBy { it.key.lowercase() }
    Column(Modifier.fillMaxSize().padding(bottom = 145.dp)) {
        TopBar(uiText(language, "artists"))
        LazyColumn {
            items(artists, key = { it.key }) { (artist, tracks) ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 7.dp).clickable { vm.play(tracks.first()) }
                        .clip(RoundedCornerShape(16.dp)).background(Surface).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Purple, Cyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(artist.take(1).uppercase(), color = White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(artist, color = White, fontWeight = FontWeight.SemiBold)
                        Text("${tracks.size} ${uiText(language, "songs").lowercase()}", color = Muted, fontSize = 12.sp)
                    }
                    Text(artist.take(1).uppercase(), color = Purple, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun FavoritesPage(vm:MainViewModel,songs:List<Song>,current:Song?,playing:Boolean) {
    val language by vm.language.collectAsState()
    val fav=songs.filter{it.id in vm.favorites.value}
    Column(Modifier.fillMaxSize().padding(bottom=145.dp)) {
        TopBar(uiText(language, "favorites"))
        if(fav.isEmpty()) EmptyState(uiText(language, "no_fav"), uiText(language, "no_fav_sub"))
        else LazyColumn { items(fav,key={it.id}){SongRow(it,vm,current,playing)} }
    }
}

@Composable
private fun SettingsPage(vm:MainViewModel, language:String) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("vagomp3_settings", Context.MODE_PRIVATE) }
    val effectiveLanguage = effectiveLanguageCode(language)
    var notifications by remember { mutableStateOf(prefs.getBoolean("notifications", true)) }
    var background by remember { mutableStateOf(prefs.getBoolean("background", true)) }
    val theme by vm.theme.collectAsState()
    val sleepRemaining by vm.sleepRemaining.collectAsState()
    var showThemes by remember { mutableStateOf(false) }
    var showLanguages by remember { mutableStateOf(false) }

    val labels = when(effectiveLanguage) {
        "ru" -> mapOf("settings" to "Настройки","theme" to "Тема","language" to "Язык","sleep" to "Таймер сна","eq" to "Эквалайзер","enabled" to "Включено","notifications" to "Уведомления","background" to "Фоновое воспроизведение","on" to "Включено","off" to "Выключено","ok" to "OK","minute" to "мин")
        "en" -> mapOf("settings" to "Settings","theme" to "Theme","language" to "Language","sleep" to "Sleep Timer","eq" to "Equalizer","enabled" to "Enabled","notifications" to "Notifications","background" to "Background playback","on" to "Enabled","off" to "Disabled","ok" to "OK","minute" to "min")
        "tr" -> mapOf("settings" to "Ayarlar","theme" to "Tema","language" to "Dil","sleep" to "Uyku Zamanlayıcısı","eq" to "Ekolayzır","enabled" to "Açık","notifications" to "Bildirimler","background" to "Arka planda oynatma","on" to "Açık","off" to "Kapalı","ok" to "Tamam","minute" to "dk")
        else -> mapOf("settings" to "Ayarlar","theme" to "Tema","language" to "Dil","sleep" to "Yuxu Taymeri","eq" to "Ekvalayzer","enabled" to "Aktiv","notifications" to "Bildirişlər","background" to "Fon rejimində dinləmə","on" to "Aktiv","off" to "Deaktiv","ok" to "OK","minute" to "dəq")
    }
    val themeNames = when(effectiveLanguage) {
        "ru" -> listOf("Vago Premium Neon","Cyberpunk","Electric Blue","Toxic Green","Luxury Gold")
        "en" -> listOf("Vago Premium Neon","Cyberpunk","Electric Blue","Toxic Green","Luxury Gold")
        "tr" -> listOf("Vago Premium Neon","Cyberpunk","Electric Blue","Toxic Green","Luxury Gold")
        else -> listOf("Vago Premium Neon","Cyberpunk","Electric Blue","Toxic Green","Luxury Gold")
    }
    val languageName = when(language) {
        "system" -> "${uiText(effectiveLanguage, "system_language")} • ${Locale.getDefault().displayLanguage.replaceFirstChar { it.uppercase() }}"
        "ru" -> "Русский"; "en" -> "English"; "tr" -> "Türkçe"; else -> "Azərbaycan dili"
    }

    Column(Modifier.fillMaxSize().padding(bottom=30.dp).verticalScroll(rememberScrollState())) {
        TopBar(labels["settings"]!!, {vm.setPage(Page.HOME)})
        SettingRow(Icons.Default.Palette,labels["theme"]!!,themeNames[theme]) { showThemes=true }
        SettingRow(Icons.Default.Language,labels["language"]!!,languageName) { showLanguages=true }
        SettingRow(Icons.Default.Bedtime,labels["sleep"]!!,if(sleepRemaining > 0) "$sleepRemaining ${labels["minute"]}" else "30 ${labels["minute"]}") {
            if (sleepRemaining > 0) vm.cancelSleepTimer() else vm.startSleepTimer(30)
        }
        SettingRow(Icons.Default.Equalizer,labels["eq"]!!,labels["enabled"]!!) {vm.setPage(Page.EQUALIZER)}
        SettingSwitch(Icons.Default.Notifications,labels["notifications"]!!,if(notifications) labels["on"]!! else labels["off"]!!,notifications) {
            notifications = !notifications; prefs.edit().putBoolean("notifications", notifications).apply()
        }
        SettingSwitch(Icons.Default.Headphones,labels["background"]!!,if(background) labels["on"]!! else labels["off"]!!,background) {
            background = !background; prefs.edit().putBoolean("background", background).apply()
        }
        Spacer(Modifier.height(16.dp))
    }

    if(showThemes) {
        AlertDialog(onDismissRequest={showThemes=false}, title={Text(labels["theme"]!!)}, text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                themeNames.forEachIndexed { i,name ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if(theme==i) Purple.copy(.18f) else Color.Transparent).clickable { vm.setTheme(i); showThemes=false }.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                        Box(
                            Modifier.size(26.dp).clip(CircleShape).background(
                                Brush.linearGradient(
                                    when(i) {
                                        0 -> listOf(Color(0xFFB026FF), Color(0xFFFF167F), Color(0xFF00E5FF))
                                        1 -> listOf(Color(0xFFFF00E5), Color(0xFF7B2CFF), Color(0xFF00F0FF))
                                        2 -> listOf(Color(0xFF3D5AFE), Color(0xFF00B8FF), Color(0xFF00F5FF))
                                        3 -> listOf(Color(0xFF39FF88), Color(0xFFB7FF00), Color(0xFF00FFD5))
                                        else -> listOf(Color(0xFFFFC857), Color(0xFFFF8A00), Color(0xFFFFE082))
                                    }
                                )
                            )
                        )
                        Spacer(Modifier.width(12.dp)); Text(name,fontWeight=if(theme==i) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }, confirmButton={TextButton({showThemes=false}){Text(labels["ok"] ?: "OK")}})
    }
    if(showLanguages) {
        val langs=listOf(
            "system" to "⚙ ${uiText(effectiveLanguage, "system_language")}",
            "az" to "🇦🇿 ${if (effectiveLanguage == "az") "Azərbaycan dili" else "Azerbaijani"}",
            "ru" to "🇷🇺 Русский",
            "en" to "🇬🇧 English",
            "tr" to "🇹🇷 Türkçe"
        )
        AlertDialog(onDismissRequest={showLanguages=false}, title={Text(labels["language"]!!)}, text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                langs.forEach { (code,name) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if(language==code) Purple.copy(.18f) else Color.Transparent).clickable { vm.setLanguage(code); showLanguages=false }.padding(14.dp)) {
                        Text(name,fontWeight=if(language==code) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }, confirmButton={TextButton({showLanguages=false}){Text(labels["ok"] ?: "OK")}})
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Surface2.copy(alpha = 0.82f))
            .border(1.dp, Border.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
            Text(value, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Pink)
    }
}

@Composable
private fun SettingSwitch(icon:ImageVector,title:String,value:String,checked:Boolean,onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp).clip(RoundedCornerShape(15.dp))
        .background(Surface).clickable(onClick=onClick).padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
        Icon(icon,null,tint=Purple,modifier=Modifier.size(22.dp))
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f)) {
            Text(title,color=White,fontSize=14.sp)
            Text(value,color=Muted,fontSize=12.sp)
        }
        Switch(checked=checked,onCheckedChange={onClick()},colors=SwitchDefaults.colors(checkedThumbColor=White,checkedTrackColor=Purple))
    }
}

@Composable
private fun EqualizerPage(vm:MainViewModel,playing:Boolean) {
    val language by vm.language.collectAsState()
    var preset by remember { mutableIntStateOf(0) }
    val labels=listOf(uiText(language,"custom"),uiText(language,"pop"),uiText(language,"rock"),uiText(language,"classical"),uiText(language,"bass"))
    Column(Modifier.fillMaxSize().padding(bottom=20.dp)) {
        TopBar(uiText(language, "eq"),{vm.setPage(Page.HOME)})
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            labels.forEachIndexed{ i,label ->
                Text(label,color=if(preset==i)White else Muted,fontSize=11.sp,modifier=Modifier.clip(RoundedCornerShape(20.dp)).background(if(preset==i)Purple.copy(.25f) else Surface).border(1.dp,if(preset==i)Purple else Border,RoundedCornerShape(20.dp)).clickable{preset=i;vm.player.setEqualizer(i)}.padding(horizontal=12.dp,vertical=8.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().padding(20.dp).height(270.dp).clip(RoundedCornerShape(24.dp)).background(Surface).border(1.dp,Border,RoundedCornerShape(24.dp))) {
            Canvas(Modifier.fillMaxSize().padding(25.dp)) {
                val points=listOf(.25f,.62f,.40f,.76f,.50f)
                val path=Path()
                points.forEachIndexed{ i,v -> val x=size.width*i/(points.size-1); val y=size.height*(1-v); if(i==0)path.moveTo(x,y) else path.lineTo(x,y)}
                drawPath(path,Brush.linearGradient(listOf(Pink,Purple)),style=Stroke(4f))
                points.forEachIndexed{ i,v -> drawCircle(Pink,8f,Offset(size.width*i/(points.size-1),size.height*(1-v))) }
            }
            Text("+12dB",color=Muted,fontSize=10.sp,modifier=Modifier.align(Alignment.TopStart).padding(16.dp))
            Text("-12dB",color=Muted,fontSize=10.sp,modifier=Modifier.align(Alignment.BottomStart).padding(16.dp))
        }
        var bass by remember { mutableFloatStateOf(0.72f) }
        var virtualizer by remember { mutableFloatStateOf(0.58f) }
        Row(Modifier.fillMaxWidth().padding(horizontal=28.dp),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
            Knob(uiText(language, "bass_boost"),bass){ bass=it; vm.setBassBoost(it) }
            Knob(uiText(language, "virtualizer"),virtualizer){ virtualizer=it; vm.setVirtualizer(it) }
        }
    }
}

@Composable private fun RowScope.Knob(title:String,value:Float,onChange:(Float)->Unit){
    Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.size(110.dp),contentAlignment=Alignment.Center){
            Canvas(Modifier.fillMaxSize()){drawArc(Purple,140f,260f,false,style=Stroke(7f));drawArc(Pink,140f,110f*value,false,style=Stroke(4f));drawCircle(Surface2,39f);drawCircle(Purple.copy(.5f),40f,style=Stroke(2f))}
            Text("${(value*100).toInt()}%",color=White,fontWeight=FontWeight.Bold)
        }
        Text(title,color=Muted,fontSize=11.sp)
        Slider(value=value,onValueChange=onChange,modifier=Modifier.padding(horizontal=6.dp),colors=SliderDefaults.colors(thumbColor=Pink,activeTrackColor=Purple))
    }
}

@Composable
private fun FullPlayer(vm:MainViewModel,song:Song?,playing:Boolean,position:Int) {
    val language by vm.language.collectAsState()
    if(song==null){EmptyState(uiText(language,"not_selected"),uiText(language,"choose_song"));return}
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Surface2, Bg))).padding(horizontal=22.dp)) {
        Row(Modifier.fillMaxWidth().padding(top=18.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton({vm.setPage(Page.HOME)}){Icon(Icons.Default.KeyboardArrowDown,null,tint=White)}
            Text(uiText(language, "playing"),color=White,fontSize=16.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center)
            IconButton({vm.setPage(Page.EQUALIZER)}){Icon(Icons.Default.Equalizer,null,tint=White)}
        }
        Spacer(Modifier.height(28.dp))
        Artwork(song,Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(25.dp)).shadow(30.dp,RoundedCornerShape(25.dp)))
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text(song.title,color=White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Text(song.artist,color=Muted,fontSize=14.sp)}
            val isFavorite = song.id in vm.favorites.collectAsState().value
            Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFavorite) uiText(language, "remove_favorite") else uiText(language, "add_favorite"),
                tint = if (isFavorite) Pink else Muted,
                modifier = Modifier.size(28.dp).clickable { vm.toggleFavorite(song) }
            )
        }
        Spacer(Modifier.height(22.dp))
        Slider(value=position.toFloat(),onValueChange={vm.player.seekTo(it.toInt())},valueRange=0f..song.duration.toFloat(),colors=SliderDefaults.colors(thumbColor=Pink,activeTrackColor=Purple,inactiveTrackColor=Border))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(formatMs(position.toLong()),color=Muted,fontSize=11.sp);Text(formatMs(song.duration),color=Muted,fontSize=11.sp)}
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
            Icon(Icons.Default.Shuffle,null,tint=if(vm.isShuffle()) Pink else Muted,modifier=Modifier.size(24.dp).clickable{vm.setShuffle(!vm.isShuffle())})
            Icon(Icons.Default.SkipPrevious,null,tint=White,modifier=Modifier.size(32.dp).clickable{vm.previous()})
            Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple,Pink))).clickable{vm.player.toggle()},contentAlignment=Alignment.Center){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=White,modifier=Modifier.size(34.dp))}
            Icon(Icons.Default.SkipNext,null,tint=White,modifier=Modifier.size(32.dp).clickable{vm.next()})
            Icon(Icons.Default.Repeat,null,tint=if(vm.isRepeat()) Pink else Muted,modifier=Modifier.size(24.dp).clickable{vm.setRepeat(!vm.isRepeat())})
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun MiniPlayer(vm:MainViewModel,song:Song,playing:Boolean,position:Int,modifier:Modifier=Modifier) {
    Row(modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp).clip(RoundedCornerShape(19.dp)).background(Surface.copy(.97f)).border(1.dp,Purple.copy(.5f),RoundedCornerShape(19.dp)).clickable{vm.setPage(Page.PLAYER)}.padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
        Artwork(song,Modifier.size(48.dp));Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)){Text(song.title,color=White,fontSize=13.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(song.artist,color=Muted,fontSize=10.sp,maxLines=1)}
        IconButton({vm.player.toggle()}){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=White)}
        IconButton({vm.setPage(Page.PLAYER)}){Icon(Icons.Default.ExpandLess,null,tint=Pink)}
    }
}

@Composable
private fun BottomNav(page:Page,onPage:(Page)->Unit,language:String,modifier:Modifier=Modifier) {
    val effectiveLanguage = effectiveLanguageCode(language)
    val labels=when(effectiveLanguage) {
        "ru" -> listOf("Главная","Песни","Альбомы","Исполнители","Избранное")
        "en" -> listOf("Home","Songs","Albums","Artists","Favorites")
        "tr" -> listOf("Ana Sayfa","Şarkılar","Albümler","Sanatçılar","Favoriler")
        else -> listOf("Ana səhifə","Mahnılar","Albomlar","İfaçılar","Sevimlilər")
    }
    val items=listOf(Page.HOME to (labels[0] to Icons.Outlined.Home),Page.SONGS to (labels[1] to Icons.Outlined.MusicNote),Page.ALBUMS to (labels[2] to Icons.Outlined.Album),Page.ARTISTS to (labels[3] to Icons.Outlined.Person),Page.FAVORITES to (labels[4] to Icons.Outlined.FavoriteBorder))
    Row(modifier.fillMaxWidth().padding(14.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xF0140A24)).border(1.dp,Border,RoundedCornerShape(28.dp)).padding(7.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
        items.forEach{(p,data)->Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(if(page==p)Purple.copy(.22f) else Color.Transparent).clickable{onPage(p)}.padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Icon(data.second,null,tint=if(page==p)White else Muted,modifier=Modifier.size(21.dp));Text(data.first,color=if(page==p)White else Muted,fontSize=9.sp,maxLines=1)
        }}
    }
}

@Composable
private fun FeatureCard(title:String,subtitle:String,icon:ImageVector,onClick:()->Unit){
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp).clip(RoundedCornerShape(22.dp)).background(Brush.horizontalGradient(listOf(Purple.copy(.30f), Cyan.copy(.10f)))).border(1.dp,Purple.copy(.4f),RoundedCornerShape(22.dp)).clickable(onClick=onClick).padding(18.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(52.dp).clip(CircleShape).background(Purple.copy(.2f)),contentAlignment=Alignment.Center){Icon(icon,null,tint=Pink,modifier=Modifier.size(26.dp))}
        Spacer(Modifier.width(14.dp));Column{Text(title,color=White,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted,fontSize=12.sp)}
    }
}

@Composable
private fun EmptyState(title:String="Musiqi tapılmadı",subtitle:String="Telefonuna MP3 və ya digər audio fayllar əlavə et."){
    Column(Modifier.fillMaxWidth().padding(45.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.size(78.dp).clip(CircleShape).background(Purple.copy(.13f)),contentAlignment=Alignment.Center){Icon(Icons.Default.LibraryMusic,null,tint=Purple,modifier=Modifier.size(38.dp))}
        Spacer(Modifier.height(14.dp));Text(title,color=White,fontSize=17.sp,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted,fontSize=12.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center,modifier=Modifier.padding(top=6.dp))
    }
}
private fun formatMs(ms:Long):String { val total=(ms/1000).toInt(); return String.format(Locale.getDefault(),"%d:%02d",total/60,total%60) }
