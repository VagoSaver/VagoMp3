# VagoMp3 — Google Play Console hazırlığı

## Hazır olanlar
- Application ID: `com.vagomp3.app`
- compileSdk: 36
- targetSdk: 36
- minSdk: 24
- Release minification + resource shrinking aktivdir
- Launcher və round icon mövcuddur
- Android 12+ splash mövcuddur
- Şəbəkə icazəsi tələb olunmur
- Cleartext HTTP söndürülüb
- Backup söndürülüb
- Privacy Policy mətninin lokal nüsxəsi `app/src/main/assets/privacy_policy.html` içindədir

## Play Console-da mütləq edilməli olanlar
1. Developer account və developer verification prosesini tamamla.
2. `com.vagomp3.app` paket adı ilə app yarat.
3. Signed Android App Bundle (`.aab`) yüklə.
4. Play App Signing-i aktivləşdir.
5. Store listing: ad, qısa təsvir, tam təsvir, app icon, feature graphic və telefon screenshot-ları əlavə et.
6. App content: target audience, content rating, ads declaration və digər uyğun sualları cavablandır.
7. Data safety formasını tətbiqin real davranışına uyğun doldur. Bu build audio kitabxanasını yalnız cihazda oxumaq üçün istifadə edir və şəbəkə icazəsi tələb etmir.
8. Privacy Policy üçün HTTPS URL təqdim et. `app/src/main/assets/privacy_policy.html` faylındakı `YOUR_SUPPORT_EMAIL@example.com` ünvanını real dəstək e-poçtu ilə dəyiş və faylı öz domenində HTTPS ilə yayımla.
9. Əgər tətbiqdə heç bir hesab sistemi yoxdursa, account deletion tələblərini hesab əsaslı funksiya kimi bəyan etmə.
10. Internal testing → Closed testing → Production mərhələləri ilə test et.

## İmzalama
Bu layihəyə developer-in şəxsi keystore-u daxil edilmir. Təhlükəsizlik səbəbilə keystore-u layihəyə yerləşdirmək düzgün deyil. Android Studio ilə:
Build → Generate Signed Bundle / APK → Android App Bundle → öz keystore-un → release.

Alternativ olaraq CI/CD-də `signing` secrets istifadə et.

## Vacib
Google Play qəbuluna heç bir layihə faylı 100% zəmanət vermir. Play Console-da verilən Data Safety, Privacy Policy və Store Listing məlumatları tətbiqin faktiki davranışı ilə tam uyğun olmalıdır.
