# VagoMp3

Premium Azərbaycan dilində Android MP3 musiqi pleyeri.

- App name: VagoMp3
- Package: `com.vagomp3.app`
- minSdk: 24
- target/compile SDK: 36
- Java/Kotlin JVM: 17
- Gradle: 9.3.1

## GitHub APK build

Repository-də layihə faylları kök qovluqdadırsa, `.github/workflows/build-apk.yml` birbaşa build edir.

ZIP əsaslı repository istifadə edirsinizsə, workflow `VagoMp3_Android_Project.zip` faylını da avtomatik tapıb extract edə bilir.

GitHub → **Actions** → **Build VagoMp3 APK** → **Run workflow**.

Build tamamlandıqdan sonra `VagoMp3-APKs` artifact içindən Debug və Release APK-ları götürə bilərsiniz.


## Launcher and splash fixes
- Launcher adaptive-icon XML was removed so the supplied VagoApps artwork is displayed at full size instead of being scaled down inside the adaptive safe zone.
- Android 12+ splash screen now uses a dedicated neon V vector (`vago_splash_v`) instead of the full app logo image, so the splash shows a prominent V letter on the black background.

## Google Play Console
Play-ready baseline: target/compile SDK 36, release shrinking enabled, no INTERNET permission, no cleartext traffic, and local privacy-policy template included.

See `PLAY_CONSOLE_CHECKLIST.md` before uploading the signed `.aab`.
