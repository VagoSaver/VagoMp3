package com.vagomp3.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Bg = Color(0xFF06070D)
private val Surface = Color(0xFF10111B)
private val Surface2 = Color(0xFF171727)
private val Border = Color(0xFF2D2944)
private val Purple = Color(0xFF9B35FF)
private val Pink = Color(0xFFFF2E93)
private val Cyan = Color(0xFF25D8FF)
private val Gold = Color(0xFFFFC857)
private val Muted = Color(0xFF8D8AA2)
private val White = Color(0xFFF8F7FF)

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val albumId: Long
)

enum class Page { HOME, SONGS, ALBUMS, ARTISTS, FAVORITES, SETTINGS, PLAYER, EQUALIZER }

class AudioLibrary(private val context: Context) {
    suspend fun scan(): List<Song> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 5000"
        context.contentResolver.query(collection, projection, selection, null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (c.moveToNext()) {
                val songId = c.getLong(id)
                result += Song(
                    songId,
                    c.getString(title)?.ifBlank { "Adsız mahnı" } ?: "Adsız mahnı",
                    c.getString(artist)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Naməlum ifaçı",
                    c.getString(album)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Naməlum albom",
                    c.getLong(duration),
                    ContentUris.withAppendedId(collection, songId),
                    c.getLong(albumId)
                )
            }
        }
        result
    }
}

class PlayerController(private val context: Context) {
    private var player: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private val _current = MutableStateFlow<Song?>(null)
    val current: StateFlow<Song?> = _current.asStateFlow()
    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing.asStateFlow()
    private val _position = MutableStateFlow(0)
    val position: StateFlow<Int> = _position.asStateFlow()

    fun play(song: Song) {
        if (_current.value?.id == song.id && player != null) {
            player?.start(); _playing.value = true; return
        }
        release()
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_MEDIA).build())
            setDataSource(context, song.uri)
            setOnPreparedListener { it.start(); _playing.value = true }
            setOnCompletionListener { _playing.value = false; _position.value = 0 }
            prepareAsync()
        }
        _current.value = song
        _position.value = 0
    }

    fun toggle() {
        player?.let { if (it.isPlaying) { it.pause(); _playing.value = false } else { it.start(); _playing.value = true } }
    }

    fun seekTo(ms: Int) { player?.seekTo(ms); _position.value = ms }
    fun updatePosition() { player?.let { if (it.isPlaying) _position.value = it.currentPosition } }

    fun setEqualizer(preset: Int) {
        val audioSession = player?.audioSessionId ?: return
        equalizer?.release()
        equalizer = Equalizer(0, audioSession).apply {
            enabled = true
            val count = numberOfPresets
            if (count > 0) usePreset(preset.coerceIn(0, count - 1).toShort())
        }
    }

    fun release() {
        equalizer?.release(); equalizer = null
        player?.release(); player = null
        _playing.value = false
    }
}

class MainViewModel : ViewModel() {
    lateinit var context: Context
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs = _songs.asStateFlow()
    private val _page = MutableStateFlow(Page.HOME)
    val page = _page.asStateFlow()
    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()
    private val _favorites = MutableStateFlow<Set<Long>>(emptySet())
    val favorites = _favorites.asStateFlow()
    lateinit var player: PlayerController

    fun init(ctx: Context) {
        if (::context.isInitialized) return
        context = ctx.applicationContext
        player = PlayerController(context)
        loadFavorites()
        scan()
    }

    private fun loadFavorites() {
        val raw = context.getSharedPreferences("vagomp3", Context.MODE_PRIVATE)
            .getStringSet("favorites", emptySet()) ?: emptySet()
        _favorites.value = raw.mapNotNull { it.toLongOrNull() }.toSet()
    }

    fun scan() { viewModelScope.launch { _songs.value = AudioLibrary(context).scan() } }
    fun setPage(p: Page) { _page.value = p }
    fun setQuery(q: String) { _query.value = q }
    fun toggleFavorite(song: Song) {
        _favorites.value = _favorites.value.toMutableSet().apply {
            if (!add(song.id)) remove(song.id)
        }.also { context.getSharedPreferences("vagomp3", 0).edit().putStringSet("favorites", it.map(Long::toString).toSet()).apply() }
    }
    fun play(song: Song) = player.play(song)
    override fun onCleared() { player.release(); super.onCleared() }
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.scan()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Bg.toArgb()
        window.navigationBarColor = Bg.toArgb()
        setContent {
            vm.init(this)
            VagoMp3App(vm, ::requestAudioPermission)
        }
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED)
            permissionLauncher.launch(permission)
        else vm.scan()
    }
}

@Composable
fun VagoMp3App(vm: MainViewModel, requestPermission: () -> Unit) {
    val songs by vm.songs.collectAsState()
    val page by vm.page.collectAsState()
    val query by vm.query.collectAsState()
    val current by vm.player.current.collectAsState()
    val playing by vm.player.playing.collectAsState()
    val position by vm.player.position.collectAsState()

    LaunchedEffect(Unit) { requestPermission() }
    LaunchedEffect(playing) {
        while (playing) { vm.player.updatePosition(); delay(500) }
    }
    BackHandler(enabled = page != Page.HOME) { vm.setPage(Page.HOME) }

    val filtered = songs.filter {
        query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Pink, tertiary = Cyan,
        background = Bg, surface = Surface, onSurface = White, onBackground = White
    )) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            AnimatedContent(page, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "page") { p ->
                when (p) {
                    Page.HOME -> HomePage(vm, songs, filtered, current, playing)
                    Page.SONGS -> SongsPage(vm, filtered, current, playing, query)
                    Page.ALBUMS -> AlbumsPage(vm, songs, current, playing)
                    Page.ARTISTS -> ArtistsPage(vm, songs)
                    Page.FAVORITES -> FavoritesPage(vm, songs, current, playing)
                    Page.SETTINGS -> SettingsPage(vm)
                    Page.PLAYER -> FullPlayer(vm, current, playing, position)
                    Page.EQUALIZER -> EqualizerPage(vm, playing)
                }
            }
            if (page != Page.PLAYER && current != null) {
                MiniPlayer(vm, current!!, playing, position, Modifier.align(Alignment.BottomCenter))
            }
            if (page != Page.PLAYER && page != Page.EQUALIZER) {
                BottomNav(page, vm::setPage, Modifier.align(Alignment.BottomCenter))
            }
        }
    }
}

@Composable
private fun Brand(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(
            Brush.linearGradient(listOf(Purple, Pink))).border(1.dp, Color.White.copy(.18f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center) {
            Text("V", color=White, fontSize=20.sp, fontWeight=FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Text("Vago", color=White, fontSize=23.sp, fontWeight=FontWeight.Bold)
        Text("Mp3", color=Pink, fontSize=23.sp, fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun TopBar(title: String = "Ana səhifə", onBack: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack, null, tint=White) }
        } else Brand()
        Spacer(Modifier.weight(1f))
        Text(title, color=White, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
private fun HomePage(vm: MainViewModel, songs: List<Song>, filtered: List<Song>, current: Song?, playing: Boolean) {
    val ctx=LocalContext.current
    Column(Modifier.fillMaxSize().padding(bottom=145.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Brand()
            IconButton(onClick={vm.setPage(Page.SETTINGS)}) { Icon(Icons.Default.Settings, null, tint=White) }
        }
        Text("Musiqini hiss et.", color=White, fontSize=31.sp, fontWeight=FontWeight.ExtraBold, modifier=Modifier.padding(horizontal=20.dp))
        Text("Sənin musiqi dünyan. Daha parlaq, daha canlı.", color=Muted, fontSize=14.sp, modifier=Modifier.padding(horizontal=20.dp, vertical=4.dp))
        SearchBox(vm)
        Row(Modifier.padding(horizontal=20.dp, vertical=14.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            QuickCard("Mahnılar", songs.size.toString(), Icons.Default.MusicNote) { vm.setPage(Page.SONGS) }
            QuickCard("Albomlar", songs.map { it.album }.distinct().size.toString(), Icons.Default.Album) { vm.setPage(Page.ALBUMS) }
            QuickCard("Sevimlilər", vm.favorites.value.size.toString(), Icons.Default.Favorite) { vm.setPage(Page.FAVORITES) }
        }
        SectionTitle("Son dinlədiklərin", "Hamısına bax") { vm.setPage(Page.SONGS) }
        if (filtered.isEmpty()) EmptyState()
        else filtered.take(7).forEach { SongRow(it, vm, current, playing) }
        Spacer(Modifier.height(24.dp))
        FeatureCard("Güclü Ekvalayzer", "Səsini zövqünə uyğunlaşdır", Icons.Default.Equalizer) { vm.setPage(Page.EQUALIZER) }
    }
}

@Composable
private fun SearchBox(vm: MainViewModel) {
    val query by vm.query.collectAsState()
    OutlinedTextField(query, vm::setQuery, Modifier.fillMaxWidth().padding(horizontal=20.dp),
        placeholder={Text("Mahnı, ifaçı və ya albom axtar...", color=Muted)},
        leadingIcon={Icon(Icons.Default.Search,null,tint=Muted)}, singleLine=true,
        shape=RoundedCornerShape(18.dp), colors=OutlinedTextFieldDefaults.colors(
            focusedBorderColor=Purple, unfocusedBorderColor=Border, focusedContainerColor=Surface, unfocusedContainerColor=Surface,
            focusedTextColor=White, unfocusedTextColor=White, cursorColor=Pink
        ))
}

@Composable
private fun RowScope.QuickCard(title:String, count:String, icon:ImageVector, click:()->Unit) {
    Column(Modifier.weight(1f).height(100.dp).clip(RoundedCornerShape(18.dp)).background(Surface)
        .border(1.dp, Border, RoundedCornerShape(18.dp)).clickable(onClick=click).padding(14.dp),
        verticalArrangement=Arrangement.SpaceBetween) {
        Icon(icon,null,tint=if(title=="Sevimlilər") Pink else Cyan,modifier=Modifier.size(25.dp))
        Text(title,color=White,fontSize=13.sp,fontWeight=FontWeight.SemiBold)
        Text(count,color=Muted,fontSize=12.sp)
    }
}

@Composable
private fun SectionTitle(title:String, action:String?=null, onAction:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
        Text(title,color=White,fontSize=18.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        if(action!=null) Text(action,color=Purple,fontSize=12.sp,modifier=Modifier.clickable{onAction?.invoke()})
    }
}

@Composable
private fun SongRow(song:Song,vm:MainViewModel,current:Song?,playing:Boolean) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=5.dp).clip(RoundedCornerShape(15.dp))
        .background(if(current?.id==song.id) Color(0xFF211638) else Color.Transparent)
        .clickable{vm.play(song)}.padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
        Artwork(song, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title,color=White,fontSize=14.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
            Text(song.artist,color=Muted,fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
        }
        Text(formatMs(song.duration),color=Muted,fontSize=11.sp)
        Icon(if(current?.id==song.id&&playing) Icons.Default.PauseCircleOutline else Icons.Default.PlayCircleOutline,null,tint=if(current?.id==song.id)Pink else White,modifier=Modifier.padding(start=8.dp).size(27.dp))
    }
}

@Composable
private fun Artwork(song:Song, modifier:Modifier=Modifier) {
    val context = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, song.uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val r=android.media.MediaMetadataRetriever()
                context.contentResolver.openFileDescriptor(song.uri,"r")?.use { r.setDataSource(it.fileDescriptor); r.embeddedPicture?.let { bytes -> android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.size) } }.also { r.release() }
            } catch (_:Throwable) { null }
        }
    }
    Box(modifier.clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFF32115A),Color(0xFF0C5E74))))) {
        if (bmp != null) AndroidView(factory = { android.widget.ImageView(it).apply { scaleType = android.widget.ImageView.ScaleType.CENTER_CROP } }, update = { it.setImageBitmap(bmp) }, modifier = Modifier.fillMaxSize())
        else Icon(Icons.Default.MusicNote,null,tint=White.copy(.7f),modifier=Modifier.align(Alignment.Center).size(24.dp))
    }
}

@Composable
private fun SongsPage(vm:MainViewModel,songs:List<Song>,current:Song?,playing:Boolean,query:String) {
    Column(Modifier.fillMaxSize().padding(bottom=145.dp)) {
        TopBar("Mahnılar"){ }
        SearchBox(vm)
        if(songs.isEmpty()) EmptyState()
        else LazyColumn(Modifier.fillMaxSize().padding(top=10.dp)) { items(songs,key={it.id}){SongRow(it,vm,current,playing)} }
    }
}

@Composable
private fun AlbumsPage(vm:MainViewModel,songs:List<Song>,current:Song?,playing:Boolean) {
    val albums=songs.groupBy{it.album}.entries.toList()
    Column(Modifier.fillMaxSize().padding(bottom=145.dp)) {
        TopBar("Albomlar")
        LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize().padding(horizontal=16.dp),contentPadding=PaddingValues(bottom=12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            items(albums,key={it.key}){ (album,tracks) ->
                Column(Modifier.clip(RoundedCornerShape(18.dp)).background(Surface).border(1.dp,Border,RoundedCornerShape(18.dp)).padding(10.dp)) {
                    Artwork(tracks.first(),Modifier.fillMaxWidth().aspectRatio(1f))
                    Text(album,color=White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(top=9.dp))
                    Text("${tracks.size} mahnı",color=Muted,fontSize=12.sp)
                }
            }
        }
    }
}

@Composable
private fun ArtistsPage(vm: MainViewModel, songs: List<Song>) {
    val artists = songs.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }
    Column(Modifier.fillMaxSize().padding(bottom = 145.dp)) {
        TopBar("İfaçılar")
        LazyColumn {
            items(artists, key = { it.key }) { (artist, tracks) ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 7.dp)
                        .clip(RoundedCornerShape(16.dp)).background(Surface).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Purple, Cyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(artist.take(1).uppercase(), color = White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(artist, color = White, fontWeight = FontWeight.SemiBold)
                        Text("${tracks.size} mahnı", color = Muted, fontSize = 12.sp)
                    }
                    Text(artist.take(1).uppercase(), color = Purple, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun FavoritesPage(vm:MainViewModel,songs:List<Song>,current:Song?,playing:Boolean) {
    val fav=songs.filter{it.id in vm.favorites.value}
    Column(Modifier.fillMaxSize().padding(bottom=145.dp)) {
        TopBar("Sevimlilər")
        if(fav.isEmpty()) EmptyState("Hələ sevimli mahnın yoxdur","Mahnıdakı ürəyə toxun və burada görünsün.")
        else LazyColumn { items(fav,key={it.id}){SongRow(it,vm,current,playing)} }
    }
}

@Composable
private fun SettingsPage(vm:MainViewModel) {
    Column(Modifier.fillMaxSize().padding(bottom=30.dp)) {
        TopBar("Ayarlar", {vm.setPage(Page.HOME)})
        SettingRow(Icons.Default.DarkMode,"Tema","Qaranlıq"){}
        SettingRow(Icons.Default.Language,"Dil","Azərbaycan dili"){}
        SettingRow(Icons.Default.Bedtime,"Yuxu Taymeri","30 dəqiqə"){}
        SettingRow(Icons.Default.Equalizer,"Ekvalayzer","Xüsusi"){vm.setPage(Page.EQUALIZER)}
        SettingRow(Icons.Default.Notifications,"Bildirişlər","Aktiv"){}
        SettingRow(Icons.Default.Headphones,"Fon rejimində dinləmə","Aktiv"){}
        Spacer(Modifier.height(18.dp))
        Text("VagoMp3 v1.0.0",color=Muted,fontSize=12.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
        Text("Musiqini hiss et.",color=Purple,fontSize=13.sp,modifier=Modifier.align(Alignment.CenterHorizontally).padding(top=5.dp))
    }
}

@Composable
private fun SettingRow(icon:ImageVector,title:String,value:String,onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp).clip(RoundedCornerShape(15.dp)).background(Surface).clickable(onClick=onClick).padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
        Icon(icon,null,tint=Purple,modifier=Modifier.size(22.dp)); Spacer(Modifier.width(15.dp))
        Text(title,color=White,fontSize=14.sp,modifier=Modifier.weight(1f)); Text(value,color=Muted,fontSize=12.sp); Icon(Icons.Default.ChevronRight,null,tint=Muted)
    }
}

@Composable
private fun EqualizerPage(vm:MainViewModel,playing:Boolean) {
    var preset by remember { mutableIntStateOf(0) }
    val labels=listOf("Xüsusi","Pop","Rock","Klassik","Bass")
    Column(Modifier.fillMaxSize().padding(bottom=20.dp)) {
        TopBar("Ekvalayzer",{vm.setPage(Page.HOME)})
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            labels.forEachIndexed{ i,label ->
                Text(label,color=if(preset==i)White else Muted,fontSize=11.sp,modifier=Modifier.clip(RoundedCornerShape(20.dp)).background(if(preset==i)Purple.copy(.25f) else Surface).border(1.dp,if(preset==i)Purple else Border,RoundedCornerShape(20.dp)).clickable{preset=i;vm.player.setEqualizer(i)}.padding(horizontal=12.dp,vertical=8.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().padding(20.dp).height(270.dp).clip(RoundedCornerShape(24.dp)).background(Surface).border(1.dp,Border,RoundedCornerShape(24.dp))) {
            Canvas(Modifier.fillMaxSize().padding(25.dp)) {
                val points=listOf(.25f,.62f,.40f,.76f,.50f)
                val path=Path()
                points.forEachIndexed{ i,v -> val x=size.width*i/(points.size-1); val y=size.height*(1-v); if(i==0)path.moveTo(x,y) else path.lineTo(x,y)}
                drawPath(path,Brush.linearGradient(listOf(Pink,Purple)),style=Stroke(4f))
                points.forEachIndexed{ i,v -> drawCircle(Pink,8f,Offset(size.width*i/(points.size-1),size.height*(1-v))) }
            }
            Text("+12dB",color=Muted,fontSize=10.sp,modifier=Modifier.align(Alignment.TopStart).padding(16.dp))
            Text("-12dB",color=Muted,fontSize=10.sp,modifier=Modifier.align(Alignment.BottomStart).padding(16.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=28.dp),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
            Knob("Bass Gücləndirici",.72f); Knob("Virtualizer",.58f)
        }
    }
}

@Composable private fun RowScope.Knob(title:String,value:Float){
    Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.size(110.dp),contentAlignment=Alignment.Center){
            Canvas(Modifier.fillMaxSize()){drawArc(Purple,140f,260f,false,style=Stroke(7f));drawArc(Pink,140f,110f*value,false,style=Stroke(4f));drawCircle(Surface2,39f);drawCircle(Purple.copy(.5f),40f,style=Stroke(2f))}
            Text("${(value*100).toInt()}%",color=White,fontWeight=FontWeight.Bold)
        }
        Text(title,color=Muted,fontSize=11.sp)
    }
}

@Composable
private fun FullPlayer(vm:MainViewModel,song:Song?,playing:Boolean,position:Int) {
    if(song==null){EmptyState("Mahnı seçilməyib","Kitabxanadan mahnı seç.");return}
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF15102A),Bg))).padding(horizontal=22.dp)) {
        Row(Modifier.fillMaxWidth().padding(top=18.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton({vm.setPage(Page.HOME)}){Icon(Icons.Default.KeyboardArrowDown,null,tint=White)}
            Text("İndi Dinlənilir",color=White,fontSize=16.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center)
            IconButton({vm.setPage(Page.EQUALIZER)}){Icon(Icons.Default.Equalizer,null,tint=White)}
        }
        Spacer(Modifier.height(28.dp))
        Artwork(song,Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(25.dp)).shadow(30.dp,RoundedCornerShape(25.dp)))
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text(song.title,color=White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Text(song.artist,color=Muted,fontSize=14.sp)}
            Icon(imageVector=Icons.Default.Favorite, contentDescription=null, tint=Pink, modifier=Modifier.size(28.dp).clickable{vm.toggleFavorite(song)})
        }
        Spacer(Modifier.height(22.dp))
        Slider(value=position.toFloat(),onValueChange={vm.player.seekTo(it.toInt())},valueRange=0f..song.duration.toFloat(),colors=SliderDefaults.colors(thumbColor=Pink,activeTrackColor=Purple,inactiveTrackColor=Border))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(formatMs(position.toLong()),color=Muted,fontSize=11.sp);Text(formatMs(song.duration),color=Muted,fontSize=11.sp)}
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
            Icon(Icons.Default.Shuffle,null,tint=Muted,modifier=Modifier.size(24.dp)); Icon(Icons.Default.SkipPrevious,null,tint=White,modifier=Modifier.size(32.dp))
            Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple,Pink))).clickable{vm.player.toggle()},contentAlignment=Alignment.Center){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=White,modifier=Modifier.size(34.dp))}
            Icon(Icons.Default.SkipNext,null,tint=White,modifier=Modifier.size(32.dp)); Icon(Icons.Default.Repeat,null,tint=Muted,modifier=Modifier.size(24.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("VagoMp3 • Musiqini hiss et.",color=Muted,fontSize=11.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun MiniPlayer(vm:MainViewModel,song:Song,playing:Boolean,position:Int,modifier:Modifier=Modifier) {
    Row(modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=67.dp).clip(RoundedCornerShape(19.dp)).background(Surface.copy(.97f)).border(1.dp,Purple.copy(.5f),RoundedCornerShape(19.dp)).clickable{vm.setPage(Page.PLAYER)}.padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
        Artwork(song,Modifier.size(48.dp));Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)){Text(song.title,color=White,fontSize=13.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(song.artist,color=Muted,fontSize=10.sp,maxLines=1)}
        IconButton({vm.player.toggle()}){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=White)}
        IconButton({vm.setPage(Page.PLAYER)}){Icon(Icons.Default.ExpandLess,null,tint=Pink)}
    }
}

@Composable
private fun BottomNav(page:Page,onPage:(Page)->Unit,modifier:Modifier=Modifier) {
    val items=listOf(Page.HOME to ("Ana səhifə" to Icons.Outlined.Home),Page.SONGS to ("Mahnılar" to Icons.Outlined.MusicNote),Page.ALBUMS to ("Albomlar" to Icons.Outlined.Album),Page.ARTISTS to ("İfaçılar" to Icons.Outlined.Person),Page.FAVORITES to ("Sevimlilər" to Icons.Outlined.FavoriteBorder))
    Row(modifier.fillMaxWidth().padding(14.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xF00D0D16)).border(1.dp,Border,RoundedCornerShape(28.dp)).padding(7.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
        items.forEach{(p,data)->Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(if(page==p)Purple.copy(.22f) else Color.Transparent).clickable{onPage(p)}.padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Icon(data.second,null,tint=if(page==p)White else Muted,modifier=Modifier.size(21.dp));Text(data.first,color=if(page==p)White else Muted,fontSize=9.sp,maxLines=1)
        }}
    }
}

@Composable
private fun FeatureCard(title:String,subtitle:String,icon:ImageVector,onClick:()->Unit){
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp).clip(RoundedCornerShape(22.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF21123A),Color(0xFF11192C)))).border(1.dp,Purple.copy(.4f),RoundedCornerShape(22.dp)).clickable(onClick=onClick).padding(18.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(52.dp).clip(CircleShape).background(Purple.copy(.2f)),contentAlignment=Alignment.Center){Icon(icon,null,tint=Pink,modifier=Modifier.size(26.dp))}
        Spacer(Modifier.width(14.dp));Column{Text(title,color=White,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted,fontSize=12.sp)}
    }
}

@Composable
private fun EmptyState(title:String="Musiqi tapılmadı",subtitle:String="Telefonuna MP3 və ya digər audio fayllar əlavə et."){
    Column(Modifier.fillMaxWidth().padding(45.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.size(78.dp).clip(CircleShape).background(Purple.copy(.13f)),contentAlignment=Alignment.Center){Icon(Icons.Default.LibraryMusic,null,tint=Purple,modifier=Modifier.size(38.dp))}
        Spacer(Modifier.height(14.dp));Text(title,color=White,fontSize=17.sp,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted,fontSize=12.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center,modifier=Modifier.padding(top=6.dp))
    }
}
private fun formatMs(ms:Long):String { val total=(ms/1000).toInt(); return String.format(Locale.getDefault(),"%d:%02d",total/60,total%60) }
